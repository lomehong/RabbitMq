﻿using Conejo;
using RabbitMq.Common;
using RabbitMq.Common.Logger;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RabbitMq.Client
{
    class Program
    {
        /// <summary>
        /// 日志
        /// </summary>
        private static ILogger logger = null;

        private static Connection _connection = null;
        private static Channel _client = null;

        private static long tps = 0;

        static void Main(string[] args)
        {
            logger = new EmptyLogger();

            _connection =
                Connection.Create(x => x
                .ConnectTo("localhost", "/")
                .WithCredentials("guest", "guest"));

            //_client =
            //    Channel.Create(_connection, x => x
            //        .ThroughDirectExchange("rpc")
            //            .WithRoutingKey("ping"));

            int threadCount = 2;
            int repeatCount = 100000000;
            bool startOtherApp = false;
            if (args.Length > 0)
            {
                threadCount = int.Parse(args[0]);
            }
            if (args.Length > 1)
            {
                repeatCount = int.Parse(args[1]);
            }
            if (args.Length > 2)
            {
                if (!string.IsNullOrEmpty(args[2]) && args[2] == "1")
                {
                    startOtherApp = true;
                }
            }

            try
            {
                //using (ConcurrentTest concurrentTest = new ConcurrentTest())
                //{
                //    var result = concurrentTest.Execute(threadCount, 1, repeatCount, Execute);
                //    foreach (var item in result)
                //    {
                //        decimal tps = 0;
                //        tps = Math.Round((decimal)threadCount / item.ElapsedMilliseconds * 1000, 2);
                //        logger.DebugFormat("线程数：{0}\t成功：{1}\t耗时：{2}\tTPS：{3}",
                //            item.ThreadCount, item.SuccessCount, item.ElapsedMilliseconds, tps);

                //    }
                //}

                // Task.Factory.StartNew(Execute, null, tokenSource.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
                // System.Diagnostics.Trace.WriteLine();

                // 起一个线程输出TPS
                Thread tpst = new Thread(new ThreadStart(OutputTps));
                tpst.Start();

                for (var i = 0; i < threadCount; i++)
                {
                    Task.Factory.StartNew(FearchDoWork);
                }
            }
            catch (Exception ex)
            {
                logger.ErrorFormat(ex.Message);
            }

            Console.ReadKey();

        }

        static void OutputTps()
        {
            Trace.Listeners.Add(new ConsoleTraceListener());
            while (true)
            {
                Thread.Sleep(1000);

                if (Interlocked.Read(ref tps) <= 0)
                {
                    continue;
                }
                Trace.WriteLine("[" + Thread.CurrentThread.ManagedThreadId + "]TPS:" + Interlocked.Read(ref tps));
                Interlocked.Exchange(ref tps, 0);
            }
        }

        static void FearchDoWork()
        {
            while (true)
            {
                Execute();
            }
        }

        static bool Execute()
        {
            Stopwatch st = new Stopwatch();
            st.Start();
            using (Channel client =
                Channel.Create(_connection, x => x
                    .ThroughDirectExchange("rpc")
                        .WithRoutingKey("ping")))
            {

                var response = client.Call<Request, Response>(new Request { Text = "hai" });
                Interlocked.Increment(ref tps);
            }
            st.Stop();
            //if (st.ElapsedMilliseconds > 50)
            //{
            //    logger.Debug("Call调用耗时：" + st.ElapsedMilliseconds);
            //}

            return true;
        }
    }
}
